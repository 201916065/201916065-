//
//  ViewController.swift
//  201916065 2
//
//  Created by 203a31 on 2022/06/02.
//

import UIKit
import AVFoundation
class ViewController: UIViewController, AVAudioPlayerDelegate {
    var audioPlayer : AVAudioPlayer!
    var audioFile : URL!
    
    
    // 노래 배열 선언
    var songlist = ["Blueming","eight","Hold My Hand","LILAC","palette","YOUI"]
    var i=0
    var musicpath = ""
    
    
    let MAX_VOLUME : Float = 10.0
    
    var progressTimer : Timer!
    let timePlayerSelector:Selector = #selector(ViewController.updatePlayTime)
    @IBOutlet var pvProgressPlay: UIProgressView!
    @IBOutlet var lblCurrentTime: UILabel!
    @IBOutlet var lblEndTime: UILabel!
    
    @IBOutlet var btnPlay: UIButton!
    @IBOutlet var btnPause: UIButton!
    @IBOutlet var btnStop: UIButton!
    @IBOutlet var btnPrevious: UIButton!
    @IBOutlet var btnNext: UIButton!
    @IBOutlet var slVolume: UISlider!
    @IBOutlet var imgView: UIImageView!
    
    @IBOutlet var btnRepeat: UIButton!
    @IBOutlet var btnRepeatStop: UIButton!
    
    
    var imgPlay = UIImage(named: "play.png")
    var imgStop = UIImage(named: "stop.png")
    var imgPause = UIImage(named: "pause.png")
    var imgRepeat = UIImage(named: "repeat.png")
    var imgRepeatStop = UIImage(named: "repeatstop.png")

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        audioFile = Bundle.main.url(forResource: songlist[i], withExtension: "mp3")
        
        initPlay()
       
        
    }
    
    // 재생 모드의 초기화
    func initPlay() {
        musicpath = Bundle.main.path(forResource: songlist[i], ofType: "mp3")!
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: musicpath))
        }
        catch let error as NSError {
            print("Error-initPlay : \(error)")
        }
        slVolume.maximumValue = MAX_VOLUME
        slVolume.value = 1.0
        pvProgressPlay.progress = 0
        
        audioPlayer.delegate = self
        audioPlayer.prepareToPlay()
        audioPlayer.volume = slVolume.value
        lblEndTime.text = convertNSTimeInterval12String(audioPlayer.duration)
        lblCurrentTime.text = convertNSTimeInterval12String(0)
        btnPlay.isEnabled = true
        btnPause.isEnabled = false
        btnStop.isEnabled = false
    }
    // 재생 일시정지 정지 버튼을 활성화 또는 비활성화하는 함수
    func setPlayButtons(_ play:Bool, pause:Bool, stop:Bool) {
        btnPlay.isEnabled = play
        btnPause.isEnabled = pause
        btnStop.isEnabled = stop
    }
    // 00:00 형태의 문자열로 변환
    func convertNSTimeInterval12String(_ time:TimeInterval) -> String {
        let min = Int(time/60)
        let sec = Int(time.truncatingRemainder(dividingBy: 60))
        let strTime = String(format: "%02d:%02d", min, sec)
        return strTime
    }
    // 재생 버튼 클릭
    @IBAction func btnPlayAudio(_ sender: UIButton) {
        audioPlayer.play()
        setPlayButtons(false, pause: true, stop: true)
        progressTimer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: timePlayerSelector, userInfo: nil, repeats: true)
        imgView.image = imgPlay
    }
    // 0.1초마다 호출되며 재생 시간을 표시
    @objc func updatePlayTime() {
        lblCurrentTime.text = convertNSTimeInterval12String(audioPlayer.currentTime)
        pvProgressPlay.progress = Float(audioPlayer.currentTime/audioPlayer.duration)
    }
    // 일시정지 버튼 클릭
    @IBAction func btnPauseAudio(_ sender: UIButton) {
        audioPlayer.pause()
        setPlayButtons(true, pause: false, stop: true)
        imgView.image = imgPause
    }
    // 반복
    @IBAction func btnRepeatAudio(_ sender: UIButton) {
        audioPlayer.play()
        audioPlayer.numberOfLoops = -1
        imgView.image = imgRepeat
    }
    
    
    //반복 정지
    @IBAction func btnRepeatStopAudio(_ sender: UIButton) {
        audioPlayer.play()
        audioPlayer.numberOfLoops = 0
        imgView.image = imgRepeatStop
    }
    

    // 정지 버튼을 클릭
    @IBAction func btnStopAudio(_ sender: UIButton) {
        audioPlayer.stop()
        audioPlayer.currentTime = 0
        lblCurrentTime.text = convertNSTimeInterval12String(0)
        setPlayButtons(true, pause: false, stop: false)
        progressTimer.invalidate()
        imgView.image = imgStop
        
    }
    // 음악 다음
    @IBAction func btnNextAudio(_ sender: UIButton) {
        if(i==songlist.capacity-1){
            i=0
        }
        else{
            i=i+1
        }
        initPlay()
        
    }
    
    //음악 이전@@@@@@@
    @IBAction func btnPreviousAudio(_ sender: UIButton) {
        if(i==songlist.capacity-1){
            i=0
        }
        else {
            i=i-1
        }
        initPlay()
    }
    
    
    // 볼륨 슬라이더 값을 audioplayer.volume에 대입
    @IBAction func slChangeVolume(_ sender: UISlider) {
        audioPlayer.volume = slVolume.value
    }
    //재생이 종료되었을 때 호출
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        progressTimer.invalidate()
        setPlayButtons(true, pause: false, stop: false)
    }
}

